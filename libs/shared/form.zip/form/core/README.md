# @app/form/core

Secondary entry point of `@app/form`. It can be used by importing from `@app/form/core`.
