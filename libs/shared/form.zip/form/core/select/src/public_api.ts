export { FormlySelectModule } from './select.module';
export { FormlySelectOptionsPipe, FormlySelectOption, FormlyFieldSelectProps } from './select-options.pipe';
